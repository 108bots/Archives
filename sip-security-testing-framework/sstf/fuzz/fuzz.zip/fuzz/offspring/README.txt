This directory contains the offspring fuzz value files (.fz) generated using the FuzzGen genetic alogrithm.
