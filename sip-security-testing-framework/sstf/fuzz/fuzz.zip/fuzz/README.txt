This directory must contain the fuzz value files (.fz). The file names should correspond to the fuzz keyword types defined
in the keyword.lst file. The spoof keywords are defined in the
spoofkeyword.lst
