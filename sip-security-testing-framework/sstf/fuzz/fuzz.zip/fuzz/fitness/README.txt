This directory must contain the fitness value files (.fit) corresponding to the fuzz value files (.fz). The file names should correspond except for the file type. 

DO NOT DELETE the 'Parameters.fit' file, it defines the fitness parameters.

FITNESS CALCULATION
===================

Parameters:
___________

Native Type: 
------------
Compare given data and check how far away it deviates from the native type (int, string, ip address etc).  Compute a deviation value, higher the deviation, higher is the contribution to the overall fitness level.

Native Size:  
------------
Compare deviation from the original, acceptable input size. Higher deviation, higher contribution to overall fitness level.

Parents Fitness: 
------------
An average of the fitness values of both the parents make a contribution.

Damage Co-efficient: 
-------------------
A value that indicates the damage caused earlier. More the damage, a particular data causes, higher is its damage co-efficient, and higher is its contribution to the fitness.

Native Character Set: 
---------------------
Check for the non-native character set, characters in the data. Higher the presence of such characters, higher is its deviation value, and higher is its contribution.

Miscellaneous (user defined):  
--------------
Format Strings, Target Reputation, Target/Attack specific data (ex: SQL data in a SQL injection attack) etc can also be taken into account.

NOTE:  All these parameters need not always be used. A single or a subset of these parameters can also be used. The overall Fitness value ranges from 1 – 10. Each Parameter’s contribution value ranges from 0 – 1. 

Fitness Calculation:
	Let X, Y, Z be the chosen parameters to contribute to the fitness value and let n be the number of parameters. Let x, y, z be their respective contribution values. The fitness value is given by:
       -----------------------------------------
       |Fit = Ceiling [ ( (x+y+z) / n ) * 10 ] |
       -----------------------------------------
